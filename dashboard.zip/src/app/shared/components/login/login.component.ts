import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUserData={email:'',password:''}
  isDisable= true;
  constructor(private _auth: AuthService, private _router: Router, private toastr: ToastrService) { 
  }

  ngOnInit(): void {
  }

  loginUser(){
    this._auth.loginUser(this.loginUserData)
      .subscribe(
        res => {
          console.log(res)
          localStorage.setItem('token',res.token)
          localStorage.setItem('loggedIn',this.loginUserData.email)
          this.toastr.success('Logged in successfully')
          this._router.navigate(['/dashboard'])
        },
        err => {
          console.log(err)
          this.toastr.error('Username or password is incorrect')
        }
      )
  }
}
