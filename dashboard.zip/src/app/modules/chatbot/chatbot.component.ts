import { Component, OnInit,  Input, AfterViewInit, ViewChild, ViewChildren, QueryList, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../models/message'
import { ChatService } from '../chat.service'

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent implements OnInit {

  user : any;
  public message : Message;
  public messages : Message[];

  // Code for Scrolling
  @ViewChild('chatlist', { read: ElementRef }) chatList: ElementRef;
  @ViewChildren(ChatbotComponent, { read: ElementRef }) chatItems: QueryList<ChatbotComponent>;

  constructor(
    private chatService : ChatService,
    private router: Router
  ) { 
    this.message = new Message('','assets/images/user.png', localStorage.getItem('loggedIn'), new Date());
  	this.messages = [
  	new Message('Welcome to chatbot universe', 'assets/images/bot.png', localStorage.getItem('loggedIn'), new Date())
  	];
  }
  separator=''

  ngOnInit(): void {
    console.log()
    let storedMessages = JSON.parse(localStorage.getItem("messages"));
    if(storedMessages != null && localStorage.getItem('loggedIn') == storedMessages[0].email){
      this.messages = storedMessages;
    }

  }

  ngAfterViewInit() {
    this.chatItems.changes.subscribe(elements => {
      this.scrollToBottom();
    });
  }

  sendMessage(){
    let token = "74538eaea1d34c61bb35455df126aed0";
    localStorage.setItem('token', token)
    this.message["timestamp"] = new Date();
    this.messages.push(this.message);
    
    this.chatService.getResponse(this.message["content"]).subscribe(res => {
      console.log(`45${res}`);
      this.messages.push(
        new Message(res.result.fulfillment.speech, 'assets/images/bot.png', localStorage.getItem('loggedIn'),res.timestamp)
      );
      console.log(`abcd${res.result.fulfillment.speech}`)

      this.scrollToBottom();
      localStorage.setItem("messages", JSON.stringify(this.messages))
    });

    this.message = new Message('', 'assets/images/user.png', localStorage.getItem('loggedIn'), new Date);
  }


  private scrollToBottom(): void {
    try {
      this.chatList.nativeElement.scrollTop = this.chatList.nativeElement.scrollHeight;
    }
    catch (err) {
      console.log('Could not find the "chatList" element.');
    }
  }

}
