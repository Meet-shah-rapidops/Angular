export class Message {
    content: string;
    timestamp: Date;
    avatar: string;
    email: string;
  
    constructor(content: string, avatar: string,email: string, timestamp?: Date){
      this.content = content;
      this.timestamp = timestamp;
      this.avatar = avatar;
      this.email = email;
    }
  }