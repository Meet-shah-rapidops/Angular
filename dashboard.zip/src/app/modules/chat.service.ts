import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ChatService {

  private baseURL: string = "https://api.dialogflow.com/v1/query?v=20150910";
  private token: string = "74538eaea1d34c61bb35455df126aed0";
  

  constructor(private http: HttpClient) { }

  public getResponse(query: string){
    let data = {
      query : query,
      lang: 'en',
      sessionId: '1234567'
    }
    let headers = new HttpHeaders().set('Authorization', `Bearer ${this.token}`);
    // headers.append('Authorization', `Bearer ${this.token}`);
    // let option = {headers:headers}
    return this.http
      .post<any>(`${this.baseURL}`, data, {headers})
      .map(res => {
        return res
      })
  }
}
