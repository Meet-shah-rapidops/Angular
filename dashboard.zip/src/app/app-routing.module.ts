import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from './layouts/default/default.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { ChatbotComponent } from './modules/chatbot/chatbot.component';
import { RegisterComponent } from './shared/components/register/register.component';
import { LoginComponent } from './shared/components/login/login.component';
import { AuthGuard } from './shared/components/auth.guard';


const routes: Routes = [
  {path: '',
    component: DefaultComponent,
  children:[{
    path: '',
    component: DashboardComponent,
    canActivate:[AuthGuard],
    pathMatch:'full'
  },{
    path:'chatbot',
    component: ChatbotComponent,
    canActivate:[AuthGuard]
  },
  {
    path : 'dashboard',
    component : DashboardComponent,
    canActivate:[AuthGuard]
  },
  {
    path : 'login',
    component : LoginComponent
  },
  {
    path : 'register',
    component : RegisterComponent
  }]
 }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
