import { Injectable } from '@angular/core';
import {AngularFireDatabaseModule, AngularFireDatabase, FirebaseListObservable} from 'angularfire2/database';
import {AngularFireAuthModule, AngularFireAuth} from 'angularfire2/auth';
import {AngularFireAuthModule, AngularFireAuth} from '@angular/fire/auth/angular-fire-auth';


import {Observable} from 'rxjs';
import {AuthService} from '../services/auth.service';
import * as firebase from 'firebase/app' 
import { ChatMessage } from '../models/chat-message.model'
@Injectable({
  providedIn: 'root'
})
export class ChatService {
  user: any;
  chatMessages: AngularFireDatabase;
  chatMessage:ChatMessage;
  username: Observable<string>;
  constructor(
    private db: AngularFireDatabase,
    private afAuth: AngularFireAuth
  ) {
    this.afAuth.authState.subscribe(auth => {
      if (auth !== undefined && auth !== null){
        this.user = auth;
      }
    })
   }

  sendMessage(msg: string){
    const timestamp  = this.getTimeStamp();
    const email = this.user.email;
    this.chatMessages = this.getMessages();
    this.chatMessages.push({
      message: msg,
      timesent: timestamp,
      username: this.username,
      email:email
    })
  }

  getMessages(): AngularFireDatabase<ChatMessage[]>{

  }

  getTimeStamp(){
    const now = new Date();
    const date = now.getUTCFullYear() + '/' + (now.getUTCMonth() + 1) + '/' + now.getUTCDate();
    const time = now.getUTCHours() + ':' + now.getUTCMinutes() + ':' + now.getUTCSeconds();
    return (date + ' ' + time);
  }
}
