import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import {ApiserviceService} from '../apiservice.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  userModel = new User('','');
  errorMsg='';
  name='Add';
  constructor(private _userservice : ApiserviceService,private route: ActivatedRoute, private router: Router) { }
  

  ngOnInit(): void {
    let id = this.route.snapshot.paramMap.get('i');
    if(id){
      this.name="Edit";
      this._userservice.getUser(id).subscribe(data=>{
        this.userModel.firstName = data.firstName,
        this.userModel.description = data.description
      }
    );
  }
  }

  add(){
    this._userservice.sendData(this.userModel)
    .subscribe(
      data => console.log('Success!!',data),
      error => this.errorMsg = error.statusText
    )
    alert("Added Successfully");
    this.router.navigate(['/']);

  }
  onSubmit(){   
    let id = this.route.snapshot.paramMap.get('i');
    if(id){
      this.edit()
    }
    else{
      this.add()
    }
  }

  edit(){
    let id = this.route.snapshot.paramMap.get('i');
    this._userservice.updateData(this.userModel,id)
      .subscribe(
        data => console.log('Success!!',data),
        error => console.log('Error!!',error)
      )
    alert("Updated Successfully");
    this.router.navigate(['/']);

  }

}
