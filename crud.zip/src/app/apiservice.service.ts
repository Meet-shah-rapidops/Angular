import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs/Observable';
import { User } from './user';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

 

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
  private _urlGet = 'http://localhost:3001/data';
  private _urlGetUser = 'http://localhost:3001/data/';
  private _urlPost = 'http://localhost:3001/data/addData';
  private _urlDelete = 'http://localhost:3001/data/deleteData/';
  private _urlUpdate = 'http://localhost:3001/data/updateData/';

  constructor(private http : HttpClient ) { }

  getData() : Observable<any>{
    return this.http.get<any>(this._urlGet)
                    .pipe(catchError(this.errorHandler))
  }

  sendData(user:User){
    console.log(user)
    return this.http.post<any>(this._urlPost, user)
        
  }

  getUser(i) : Observable<any>{
    return this.http.get<any>(this._urlGetUser+i);
  }

  deleteData(i){
    return this.http.delete(this._urlDelete + i);
  }

  updateData(user:User,i){
    console.log(user)
    return this.http.put<any>(this._urlUpdate + i, user);
  }

  errorHandler(error: HttpErrorResponse){
      return throwError(error);
  }

}
