export class User {
    constructor(
        public firstName: string,
        public description: string
    ){}
}
