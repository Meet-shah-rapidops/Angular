import { Component, OnInit } from '@angular/core';
import {ApiserviceService} from '../apiservice.service';
import { User } from '../user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  commits=[];
  errorMsg='';
  alert:boolean=false;
  userModel = new User('','');


  constructor(private _userservice : ApiserviceService) { }
  ngOnInit(): void {
    this._userservice.getData().subscribe(data=>{this.commits =data;
      console.log(this.commits)}
      );
    }

    delete(i){
      if(confirm('Are you sure to delete??')){
        this._userservice.deleteData(i).subscribe(res=>{
          this.ngOnInit();
               console.log("deleted",res)
                this.alert=true              
        },
        error =>this.errorMsg = error.statusText)
      }
    }
}

