import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div>
              <h3>Signin page</h3>
                <input type="text" #uname placeholder="enter username"/><br>
                <input type="password" #pswd placeholder="enter password"/><br>
                <button id="submitBtn" (click)='clicked(uname.value,pswd.value)'>Submit</button>
                <p id='result' [style.color] = "error ? 'red' : 'green'"></p>
              </div>`,

  styles: [` 
                input{
                  margin: 5px;
                }
          `]
})
export class AppComponent{
  title = 'task2';
  isDisable= true;
  error = true;


clicked(value1,value2){
  if(value1===''||value2===''){
    console.log("error");
    document.getElementById('result').innerHTML='Please fill all the fields its required..';
  }else{
    console.log("Username="+value1, "Password="+value2);
    this.error = false;
    document.getElementById('result').innerHTML= 'Successfully logged in...';
  }
  }
}