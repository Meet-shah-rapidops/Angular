import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridAngular } from 'ag-grid-angular';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ag-grid';
  @ViewChild('agGrid',{ static:false }) agGrid: AgGridAngular;
  columnDefs=[
    {
      rowDrag: true,
      headerName: 'Athlete',
      field: 'athlete', 
      sortable:true, 
      filter: true,
      checkboxSelection: true,
      width:150,
    },
    { 
      headerName: 'Age', 
      field: 'age', 
      sortable:true, 
      filter: true,
      width:90,
    },
    { 
      headerName: 'Country', 
      field: 'country', 
      sortable:true, 
      filter: true,
      width:120,
    },
    { 
      headerName: 'Year', 
      field: 'year', 
      sortable:true, 
      filter: true,
      width:90, 
    },
    { 
      headerName: 'Gold', 
      field: 'gold', 
      sortable:true, 
      filter: true,
      width:100, 
    },
    { 
      headerName: 'Silver', 
      field: 'silver', 
      sortable:true, 
      filter: true,
      width:100, 
    },
    { 
      headerName: 'Bronze', 
      field: 'bronze', 
      sortable:true, 
      filter: true,
      width:100, 
    },
    { 
      headerName: 'Total', 
      field: 'total', 
      sortable:true, 
      filter: true,
      width:100, 
    },
  ];

  rowData: any;

  constructor(private http: HttpClient){}

  ngOnInit(){
   this.rowData = this.http.get("https://raw.githubusercontent.com/ag-grid/ag-grid-docs/master/src/olympicWinnersSmall.json")
  }

  getSelectedRows(){
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map(node => node.data);
    const selectedDataStringPresentation = selectedData.map(node=>node.athlete+": "+node.country).join(', ');
    alert(`selectedNodes: ${selectedDataStringPresentation}`);
  }
}
