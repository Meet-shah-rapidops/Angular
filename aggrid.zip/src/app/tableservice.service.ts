import { Injectable } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Http, Response, RequestOptions, Headers} from '@angular/http';

import 'rxjs/Rx';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common'; 

@Injectable({
  providedIn: 'root'
})
export class TableserviceService {

  private servUrl = "https://raw.githubusercontent.com/ag-grid/ag-grid-docs/master/src/olympicWinnersSmall.json";
  constructor(private http: Http) { }
  //method to get all employee
  getEmployees(): Observable<Response> {
      return this.http.get(this.servUrl);
  }
}
