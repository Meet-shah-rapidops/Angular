import { Component, OnInit } from '@angular/core';
import { GridApi, GridOptions, IDatasource, IGetRowsParams } from 'ag-grid-community';
import { ApiCallService } from '../api-call.service';

@Component({
  selector: 'app-ag-grid-pagination',
  templateUrl: './ag-grid-pagination.component.html',
  styleUrls: ['./ag-grid-pagination.component.css']
})
export class AgGridPaginationComponent implements OnInit {
private gridApi:GridApi;
private pgno:number = 1;

columnDefs=[
  {
    headerName:'FisrtName',
    field:'firstName',
  },
  {
    headerName:'Description',
    field:'description',
  },
]

constructor(private api : ApiCallService) { }

 gridOptions: GridOptions = {
  pagination: true,
  rowModelType: 'infinite',
  cacheBlockSize: 5, 
  paginationPageSize: 5
};

onGridReady(params){
   this.gridApi=params.api;
   this.gridApi.sizeColumnsToFit();
   this.gridApi.setDatasource(this.dataSource);
 }

 dataSource: IDatasource = {
  getRows: (params: IGetRowsParams) => {
    this.api.getData(this.pgno,this.gridOptions.paginationPageSize).subscribe(response => {
      params.successCallback( 
        response.data,null
      );
      console.log(this.pgno)
      this.pgno+=1
      console.log('ag-grid',response.data);
    })
  }
}
  ngOnInit(): void {
  }

}
