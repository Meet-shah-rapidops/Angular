import { Component, OnInit } from '@angular/core';
import { ApiCallService } from '../api-call.service';

@Component({
  selector: 'app-newgrid',
  templateUrl: './newgrid.component.html',
  styleUrls: ['./newgrid.component.css']
})
export class NewgridComponent implements OnInit {
  // title = 'app';
  commits: Array<any>;
  totalRec : number;
  page: number = 1;
  constructor(private api : ApiCallService) { 
    this.commits = new Array<any>();
  }

  ngOnInit(): void {
    this.loadEmployee()
    
  }
  pageChanged(event){console.log("pageChanged")}

  loadEmployee() {
    this
        .api
        .getData(this.page,5)
        .subscribe((data) => {
            this.commits = data.data;
            this.totalRec = data.pages;
            // console.log(this.totalRec);
            console.log(this.page);
            console.log('html',data.data);
            
        });
}
}
