import { Component, OnInit } from '@angular/core';
import { TestserviceService } from '../testservice.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  commits=[];
  constructor(private _userservice : TestserviceService) { }

  ngOnInit(): void {
    this._userservice.getData().subscribe(data=>{this.commits =data;
      console.log(this.commits)}
      );
    }

}
