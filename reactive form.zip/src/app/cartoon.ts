export interface Cartoon {
    id: number;
    name: string;
    selected: boolean;
  }